$user = "username";
$pass = "password";
$server = "servername";

$bind_id = ldap_bind($server,$user,$pass)