## Example: Policy Definition

This example provisions a Policy Definition.
