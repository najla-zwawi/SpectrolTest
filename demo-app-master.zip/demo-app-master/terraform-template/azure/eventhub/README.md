## Example: EventHub

This example provisions an EventHub Namespace, containing an EventHub and an EventHub Consumer Group.
