## Example: Traffic Manager

This example provisions a Traffic Manager Profile with no Endpoints configured.
