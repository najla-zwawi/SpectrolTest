## Example: Traffic Manager fronting Virtual Machine Scale Sets

This example shows how to create a load balanced scale set in multiple locations and then geographically load balance these using traffic manager. This example the scale set uses a market place Ubuntu image, this could be customised using an extension or a generalized image created using packer.
