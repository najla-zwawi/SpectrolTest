## Example: Azure Stream Analytics

This example provisions an Azure Storage Account and a Stream Analytics job, that uses it as a reference input.
