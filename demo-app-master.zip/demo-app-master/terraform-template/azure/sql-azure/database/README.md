## Example: Azure SQL Database

This example provisions an Azure SQL Database.
