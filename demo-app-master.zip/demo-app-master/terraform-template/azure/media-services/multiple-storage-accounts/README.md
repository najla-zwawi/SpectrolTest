## Example: Media Services

This example provisions a Media Service with multiple Storage Accounts.

### Variables

* `prefix` - (Required) The prefix used for all resources in this example.

* `location` - (Required) The Azure Region in which the resources in this example should be created.
