# Example: a Basic (Windows) App Service with AD and Microsoft authentication enabled.

This example provisions a basic Windows App Service with AD and Microsoft authentication enabled.
