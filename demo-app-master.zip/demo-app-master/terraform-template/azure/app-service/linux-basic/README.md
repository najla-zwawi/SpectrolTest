# Example: a Basic Linux App Service

This example provisions a basic Linux App Service.
