# Example: an App Service with a Scheduled Backup

This example provisions an App Service with a Backup configured.
