# Example: a (Windows) App Service for a Java App

This example provisions a Windows App Service which is configured to run Java.
