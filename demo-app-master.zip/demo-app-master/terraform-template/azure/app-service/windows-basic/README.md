# Example: a Basic (Windows) App Service

This example provisions a basic Windows App Service.
