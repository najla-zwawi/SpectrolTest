# Example: a Linux App Service with Node.JS

This example provisions a basic Linux App Service configured for a Node.JS app.
