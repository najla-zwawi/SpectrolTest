## Example: App Service configured for Windows Container

This example provisions an App Service inside an App Service Plan which is configured to run a Windows Container.