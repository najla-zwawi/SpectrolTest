## Examples of using the App Service Resources

This folder contains examples of using the App Service resources.
