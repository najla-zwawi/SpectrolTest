## Example: Logic App

This example provisions a Logic App within Azure which sends a `HTTP DELETE` every hour to a given URI.

### Variables

* `prefix` - (Required) The prefix used for all resources in this example.

* `location` - (Required) The Azure Region in which the Logic App should be created.
