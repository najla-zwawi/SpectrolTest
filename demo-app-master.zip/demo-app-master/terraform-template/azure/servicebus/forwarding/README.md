## Example: ServiceBus Topic forwarding to another ServiceBus Topic

This example provisions a ServiceBus Topic which forwards messages to another ServiceBus Topic.
