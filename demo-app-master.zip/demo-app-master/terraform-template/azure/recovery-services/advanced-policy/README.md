## Example: Recovery Services Vault

This example provisions a Recovery Services Vault with an advanced backup policy.
