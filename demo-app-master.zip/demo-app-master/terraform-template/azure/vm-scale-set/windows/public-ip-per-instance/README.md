## Example: Windows Virtual Machine Scale Set with a Public IP per Instance

This example provisions a Windows Virtual Machine Scale Set with a Public IP per Instance.
