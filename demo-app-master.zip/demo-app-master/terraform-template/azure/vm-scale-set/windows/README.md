# Examples for Windows Virtual Machine Scale Set

This directory contains example of how to use the Windows Virtual Machine Scale Set resource.
