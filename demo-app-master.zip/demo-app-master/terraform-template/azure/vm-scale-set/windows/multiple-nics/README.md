## Example: Windows Virtual Machine Scale Set with Multiple Network Interfaces

This example provisions a Windows Virtual Machine Scale Set with Multiple Network Interfaces.
