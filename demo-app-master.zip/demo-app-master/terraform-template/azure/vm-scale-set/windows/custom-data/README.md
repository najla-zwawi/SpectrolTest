## Example: Windows Virtual Machine Scale Set with Custom Data

This example provisions a Windows Virtual Machine Scale Set with Custom Data.
