## Example: Windows Virtual Machine Scale Set with an IPv6 Address

This example provisions a Windows Virtual Machine Scale Set with an IPv6 Address.
