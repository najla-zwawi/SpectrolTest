## Example: Windows Virtual Machine Scale Set configured as Service Fabric Nodes

This example provisions a Windows Virtual Machine Scale Set configured as Service Fabric Nodes.
