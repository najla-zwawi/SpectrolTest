## Example: Windows Virtual Machine Scale Set spread across Zones

This example provisions a basic Windows Virtual Machine Scale Set spread across Zones.

Support for Zones in Azure varies based on the Azure Region being used - this example uses Zones 1-3.
