## Example: Spot instance Windows Virtual Machine Scale Set

This example provisions a Spot instance Windows Virtual Machine Scale Set.
