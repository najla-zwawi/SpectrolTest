## Example: Windows Virtual Machine Scale Set with a Certificate from Key Vault

This example provisions a Windows Virtual Machine Scale Set configured with a Certificate from Azure Key Vault.
