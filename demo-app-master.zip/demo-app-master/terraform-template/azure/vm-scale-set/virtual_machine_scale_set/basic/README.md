## Example: Virtual Machine Scale Set

This example provisions a Virtual Machine Scale Set with Managed Disks.
