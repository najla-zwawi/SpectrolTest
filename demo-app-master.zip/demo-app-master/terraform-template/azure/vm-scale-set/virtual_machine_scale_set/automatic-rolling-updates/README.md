## Example: Virtual Machine Scale Set with Rolling Automatic Updates

This example provisions a Virtual Machine Scale Set with Managed Disks and Rolling Automatic Updates configured.

More information about [Rolling Automatic Updates can be found in the Azure documentation](https://docs.microsoft.com/en-us/azure/virtual-machine-scale-sets/virtual-machine-scale-sets-automatic-upgrade).
