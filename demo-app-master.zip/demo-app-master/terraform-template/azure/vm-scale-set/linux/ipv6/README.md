## Example: Linux Virtual Machine Scale Set with an IPv6 Address

This example provisions a Linux Virtual Machine Scale Set using a password for authentication with an IPv6 Address.
