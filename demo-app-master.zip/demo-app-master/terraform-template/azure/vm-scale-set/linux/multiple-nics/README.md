## Example: Linux Virtual Machine Scale Set with Multiple Network Interfaces

This example provisions a Linux Virtual Machine Scale Set using a password for authentication with Multiple Network Interfaces.
