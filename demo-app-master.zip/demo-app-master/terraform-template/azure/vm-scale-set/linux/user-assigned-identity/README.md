## Example: Linux Virtual Machine Scale Set with a User-Assigned Identity

This example provisions a Linux Virtual Machine Scale Set using a password for authentication which has a User Assigned Identity.
