## Example: Linux Virtual Machine Scale Set with a Certificate from Key Vault

This example provisions a Linux Virtual Machine Scale Set using a password for authentication configured with a Certificate from Azure Key Vault.
