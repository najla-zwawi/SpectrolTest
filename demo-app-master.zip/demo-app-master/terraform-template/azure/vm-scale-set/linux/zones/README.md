## Example: Linux Virtual Machine Scale Set spread across Zones

This example provisions a Linux Virtual Machine Scale Set using a password for authentication spread across Zones.

Support for Zones in Azure varies based on the Azure Region being used - this example uses Zones 1-3.
