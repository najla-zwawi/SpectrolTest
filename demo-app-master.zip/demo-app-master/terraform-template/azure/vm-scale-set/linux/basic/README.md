## Example: Basic Linux Virtual Machine Scale Set

This example provisions a basic Linux Virtual Machine Scale Set using a password for authentication.
