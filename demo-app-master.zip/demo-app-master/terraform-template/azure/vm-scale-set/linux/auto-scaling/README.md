## Example: Linux Virtual Machine Scale Set with Auto-Scaling

This example provisions a Linux Virtual Machine Scale Set using a password for authentication with Auto-Scaling Configured.
