## Example: Log Analytics Workspace

This example provisions a Log Analytics Workspace.
