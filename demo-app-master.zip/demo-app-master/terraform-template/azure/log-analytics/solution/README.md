## Example: Log Analytics Workspace configured with a Container Monitor Solution

This example provisions a Log Analytics Workspace with a Container Monitoring Solution.
