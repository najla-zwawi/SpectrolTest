## Example: Automation Account

This example provisions an Automation Account
