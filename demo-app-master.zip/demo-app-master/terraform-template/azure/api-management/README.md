## Example: API Management

This example provisions an API Management service, containing an API based on a provided Open API spec, a Group, and a Product that is associated with both.
