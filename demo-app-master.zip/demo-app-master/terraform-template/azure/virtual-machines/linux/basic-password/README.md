## Example: Basic Linux Virtual Machine

This example provisions a basic Linux Virtual Machine using a password for authentication.
