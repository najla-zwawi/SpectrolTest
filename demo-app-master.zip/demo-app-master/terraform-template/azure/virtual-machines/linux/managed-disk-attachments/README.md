## Example: Basic Linux Virtual Machine

This example provisions a basic Linux Virtual Machine with additional managed data disk.
