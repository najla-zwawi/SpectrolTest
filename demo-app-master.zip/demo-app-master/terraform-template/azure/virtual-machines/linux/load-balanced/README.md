## Example: Basic Linux Virtual Machine

This example provisions a basic Linux Virtual Machine with a public IP and a Network Security Group
