## Example: Linux Virtual Machine with an Ephemeral OS Disk

This example provisions a Linux Virtual Machine with an Ephemeral OS Disk.
