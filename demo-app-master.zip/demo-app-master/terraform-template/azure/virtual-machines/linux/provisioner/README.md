## Example: Linux Virtual Machine with a Provisioner

This example provisions a Linux Virtual Machine with a Public IP and then SSH's to it with a Provisioner.
