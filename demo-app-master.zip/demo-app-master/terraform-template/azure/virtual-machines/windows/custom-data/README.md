## Example: Windows Virtual Machine with Custom Data

This example provisions a Windows Virtual Machine with some Custom Data.
