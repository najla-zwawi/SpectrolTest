## Example: Basic Virtual Machine with a Public IP Address using a Managed Disk

This example provisions a Virtual Machine with no Data Disks with a Managed Disk as the main OS Disk and a Public IP.

Notes:

- The files involved in this example are split out to make it easier to read, however all of the resources could be combined into a single file if needed.
