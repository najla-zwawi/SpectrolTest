## Example: Basic Virtual Machine using a Managed Disk

This example provisions a Virtual Machine with a Managed Disk as the main OS Disk (and no External Data Disks).

Notes:

- The files involved in this example are split out to make it easier to read, however all of the resources could be combined into a single file if needed.
