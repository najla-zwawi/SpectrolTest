## Example: Data Lake

This example provisions a Data Lake Account within a Data Lake Store
