## Example: Private Endpoint

This example provisions a Private Endpoint in Azure connected to a CosmosDB Account configured with MongoDB.

### Variables

* `prefix` - (Required) The prefix used for all resources in this example.

* `location` - (Required) The Azure Region in which all resources in this example should be created.
