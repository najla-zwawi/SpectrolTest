## Example: Private Endpoint

This example provisions a Private Endpoint which connects to a PostgreSQL server within Azure.

### Variables

* `prefix` - (Required) The prefix used for all resources in this example.

* `location` - (Required) The Azure Region in which all resources in this example should be created.
