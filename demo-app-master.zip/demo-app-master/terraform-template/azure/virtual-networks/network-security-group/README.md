## Example: Virtual Network with a Network Security Group

This example provisions a Virtual Network containing a single Subnet, with a Network Security Group.
