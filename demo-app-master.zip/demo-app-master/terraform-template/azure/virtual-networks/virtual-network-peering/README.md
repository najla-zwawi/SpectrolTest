## Example: Peering 2 Virtual Networks

This example provisions 2 Virtual Networks and then peers them using the `azurerm_virtual_network_peering` resource.
