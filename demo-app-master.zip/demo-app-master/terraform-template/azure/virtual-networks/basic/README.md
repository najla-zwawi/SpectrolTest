## Example: Virtual Network

This example provisions a Virtual Network containing a single Subnet.
