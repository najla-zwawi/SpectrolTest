## Example: Private Link Service

 This example provisions a Private Link Service.