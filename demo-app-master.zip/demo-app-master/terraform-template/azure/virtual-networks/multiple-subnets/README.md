## Example: Virtual Network with multiple Subnets

This example provisions a Virtual Network containing a 3 Subnets.
