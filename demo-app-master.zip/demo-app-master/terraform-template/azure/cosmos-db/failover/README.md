## Example: CosmosDB

This example provisions a CosmosDB Account with a failover to an alternate region.
