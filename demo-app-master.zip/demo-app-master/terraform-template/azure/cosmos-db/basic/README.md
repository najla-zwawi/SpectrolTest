## Example: CosmosDB

This example provisions a CosmosDB Account in a single region.
